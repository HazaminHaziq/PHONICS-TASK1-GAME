# The Grand Circus CVC Fairground (Year 1 Phonics)

Interactive short-vowel CVC blending game for Year 1 pupils.
Teacher Studio PIN: 1234

## Publish on GitHub Pages
1. Upload ALL files and folders in this project to the ROOT of your repository (keep the .github folder).
2. Repo Settings > Pages > Build and deployment > Source: GitHub Actions.
3. Open the Actions tab. When "Deploy to GitHub Pages" shows a green tick, your game is live at
   https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/
