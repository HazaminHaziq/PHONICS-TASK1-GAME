import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Volume2, ArrowLeft, ArrowRight, RefreshCw } from 'lucide-react';
import { CircusTent, CVCWord, VowelCategory } from '../types/phonics';
import { audioEngine } from '../utils/audioEngine';

interface BalloonPopStageProps {
  tent: CircusTent;
  onBackToHub: () => void;
  onNextTent: () => void;
  onPrevTent: () => void;
  onWordMastered: (wordId: string) => void;
  allTents: CircusTent[];
  onSelectTentById: (id: string) => void;
}

interface BalloonItem {
  id: string;
  vowel: VowelCategory;
  leftPercent: number;
  speedSec: number;
  colorClass: string;
}

export const BalloonPopStage: React.FC<BalloonPopStageProps> = ({
  tent,
  onBackToHub,
  onWordMastered,
  allTents,
  onSelectTentById
}) => {
  const [wordIndex, setWordIndex] = useState<number>(0);
  const currentWord: CVCWord = tent.words[wordIndex];

  const [selectedVowel, setSelectedVowel] = useState<VowelCategory | null>(null);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const [balloons, setBalloons] = useState<BalloonItem[]>([]);

  const spawnBalloons = () => {
    const vowelList: VowelCategory[] = ['a', 'e', 'i', 'o', 'u'];
    const colors = [
      'from-rose-400 to-red-600',
      'from-emerald-400 to-teal-600',
      'from-indigo-400 to-blue-600',
      'from-amber-400 to-orange-600',
      'from-purple-400 to-fuchsia-600'
    ];

    const newBalloons: BalloonItem[] = vowelList.map((v, i) => ({
      id: `${v}-${Date.now()}-${i}`,
      vowel: v,
      leftPercent: 12 + i * 18,
      speedSec: 4.5 + Math.random() * 2,
      colorClass: colors[i % colors.length]
    }));
    setBalloons(newBalloons);
  };

  // Reset to the first word whenever the tent changes
  useEffect(() => {
    setWordIndex(0);
  }, [tent.id]);

  useEffect(() => {
    setSelectedVowel(null);
    setIsSuccess(false);
    setFeedbackMsg(null);
    spawnBalloons();
  }, [tent.id, wordIndex]);

  const handlePopBalloon = (v: VowelCategory) => {
    audioEngine.playPop();

    if (v === currentWord.vowel) {
      setSelectedVowel(v);
      setIsSuccess(true);
      setFeedbackMsg(`Brilliant! /${v}/ completes "${currentWord.word.toUpperCase()}"!`);

      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.6 }
      });

      // Onset -> vowel -> rime -> full word
      setTimeout(() => audioEngine.playPhoneme(currentWord.onset), 100);
      setTimeout(() => audioEngine.playPhoneme(v), 550);
      setTimeout(() => audioEngine.playPhoneme(currentWord.rime), 1000);
      setTimeout(() => {
        audioEngine.playFanfare();
        audioEngine.playWord(currentWord.word);
      }, 1600);

      onWordMastered(currentWord.id);
    } else {
      setFeedbackMsg(`Oops! /${v}/ does not make "${currentWord.word.toUpperCase()}". Try again!`);
      setTimeout(() => setFeedbackMsg(null), 2500);
    }
  };

  const handleNextWord = () => {
    if (wordIndex < tent.words.length - 1) {
      setWordIndex(wordIndex + 1);
    } else {
      setWordIndex(0);
    }
  };

  const handlePrevWord = () => {
    if (wordIndex > 0) {
      setWordIndex(wordIndex - 1);
    } else {
      setWordIndex(tent.words.length - 1);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-4 flex flex-col items-center">
      <div className="w-full flex items-center justify-between mb-4 bg-white/95 rounded-2xl p-3 border-2 border-amber-300 shadow-md">
        <button
          onClick={onBackToHub}
          className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-fun text-xs font-bold flex items-center gap-1 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>All Tents</span>
        </button>

        <div className="flex items-center gap-1">
          {allTents.map(t => (
            <button
              key={t.id}
              onClick={() => onSelectTentById(t.id)}
              className={`w-8 h-8 rounded-xl font-fun font-bold text-xs flex items-center justify-center cursor-pointer transition-all ${
                t.id === tent.id
                  ? 'bg-red-600 text-white scale-110 shadow-sm'
                  : 'bg-amber-100 hover:bg-amber-200 text-amber-900'
              }`}
            >
              {t.vowel.toUpperCase()}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrevWord}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <span className="font-fun text-xs font-bold text-slate-700">
            {wordIndex + 1} / {tent.words.length}
          </span>
          <button
            onClick={handleNextWord}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="w-full bg-white/95 rounded-3xl p-6 border-3 border-amber-300 shadow-xl flex flex-col items-center text-center relative mb-6">
        <div className="relative mb-3">
          <div className="w-28 h-28 rounded-3xl bg-amber-50 border-3 border-amber-300 flex items-center justify-center text-6xl shadow-inner">
            {currentWord.correctPicture.emoji}
          </div>
          <button
            onClick={() => audioEngine.playWord(currentWord.word)}
            className="absolute -bottom-2 -right-2 p-2 rounded-full bg-red-600 hover:bg-red-700 text-white shadow-md cursor-pointer hover:scale-110 transition-transform"
            title="Listen to full word"
          >
            <Volume2 className="w-4 h-4" />
          </button>
        </div>

        <span className="font-body text-xs font-medium text-slate-600 max-w-md mb-4">
          Clue: {currentWord.clueText}
        </span>

        <div className="flex items-center gap-3 sm:gap-4 mb-4">
          <button
            onClick={() => audioEngine.playPhoneme(currentWord.onset)}
            className="w-16 h-20 sm:w-20 sm:h-24 rounded-2xl bg-amber-100 border-3 border-amber-300 text-amber-950 font-fun font-black text-3xl sm:text-4xl flex flex-col items-center justify-center shadow-md hover:bg-amber-200 cursor-pointer transition-all active:scale-95"
            title="Hear Onset Sound"
          >
            <span>{currentWord.onset}</span>
            <span className="text-[10px] font-mono font-normal text-amber-700">
              {currentWord.onsetIPA}
            </span>
          </button>

          <div
            className={`w-16 h-20 sm:w-20 sm:h-24 rounded-2xl border-3 flex flex-col items-center justify-center font-fun font-black text-3xl sm:text-4xl shadow-md transition-all ${
              selectedVowel
                ? 'bg-rose-500 border-rose-600 text-white scale-105'
                : 'border-2 border-dashed border-red-400 bg-red-50/50 text-red-400 animate-pulse'
            }`}
          >
            {selectedVowel ? (
              <>
                <span>{selectedVowel}</span>
                <span className="text-[10px] font-mono font-normal text-rose-100">
                  {currentWord.vowelIPA}
                </span>
              </>
            ) : (
              <span className="text-2xl opacity-60">?</span>
            )}
          </div>

          <button
            onClick={() => audioEngine.playPhoneme(currentWord.rime)}
            className="w-16 h-20 sm:w-20 sm:h-24 rounded-2xl bg-amber-100 border-3 border-amber-300 text-amber-950 font-fun font-black text-3xl sm:text-4xl flex flex-col items-center justify-center shadow-md hover:bg-amber-200 cursor-pointer transition-all active:scale-95"
            title="Hear Rime Sound"
          >
            <span>{currentWord.rime}</span>
            <span className="text-[10px] font-mono font-normal text-amber-700">
              {currentWord.rimeIPA}
            </span>
          </button>
        </div>

        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs font-bold text-slate-500 mr-1">Tap sounds:</span>
          <button
            onClick={() => audioEngine.playPhoneme(currentWord.onset)}
            className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-amber-100 text-slate-800 text-xs font-fun font-bold flex items-center gap-1 cursor-pointer"
          >
            <Volume2 className="w-3.5 h-3.5 text-amber-600" />
            <span>/{currentWord.onset}/</span>
          </button>
          <button
            onClick={() => audioEngine.playPhoneme(currentWord.vowel)}
            className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-rose-100 text-slate-800 text-xs font-fun font-bold flex items-center gap-1 cursor-pointer"
          >
            <Volume2 className="w-3.5 h-3.5 text-rose-600" />
            <span>/{currentWord.vowel}/</span>
          </button>
          <button
            onClick={() => audioEngine.playPhoneme(currentWord.rime)}
            className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-amber-100 text-slate-800 text-xs font-fun font-bold flex items-center gap-1 cursor-pointer"
          >
            <Volume2 className="w-3.5 h-3.5 text-amber-600" />
            <span>/{currentWord.rime}/</span>
          </button>
        </div>

        {feedbackMsg && (
          <div className={`mt-2 px-4 py-2 rounded-xl text-xs font-bold ${
            isSuccess ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-rose-100 text-rose-800 border border-rose-300'
          }`}>
            {feedbackMsg}
          </div>
        )}
      </div>

      <div className="w-full bg-amber-950/40 rounded-3xl p-6 border-2 border-amber-300/60 shadow-xl relative min-h-[160px] flex flex-col items-center justify-center">
        <span className="font-fun text-xs font-bold text-yellow-300 uppercase tracking-widest mb-3">
          🎈 Tap the correct floating vowel balloon to pop it into the word! 🎈
        </span>

        <div className="flex items-center justify-center gap-3 sm:gap-5 flex-wrap">
          {balloons.map((b) => (
            <button
              key={b.id}
              onClick={() => handlePopBalloon(b.vowel)}
              className={`w-14 h-18 sm:w-16 sm:h-20 rounded-full bg-gradient-to-t ${b.colorClass} border-2 border-white shadow-lg text-white font-fun text-2xl sm:text-3xl font-black flex flex-col items-center justify-center relative cursor-pointer active:scale-90 hover:scale-110 transition-transform`}
              style={{
                boxShadow: '0 8px 16px rgba(0,0,0,0.3), inset 0 -4px 6px rgba(0,0,0,0.2)'
              }}
            >
              <span>{b.vowel.toUpperCase()}</span>
              <div className="w-2 h-2 bg-inherit border-b border-r border-white/50 rotate-45 -mb-2" />
              <div className="w-0.5 h-4 bg-white/70 -mb-5" />
            </button>
          ))}
        </div>

        <button
          onClick={spawnBalloons}
          className="mt-6 text-xs text-amber-200 hover:text-white flex items-center gap-1 font-semibold cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Release Fresh Balloons</span>
        </button>
      </div>
    </div>
  );
};
