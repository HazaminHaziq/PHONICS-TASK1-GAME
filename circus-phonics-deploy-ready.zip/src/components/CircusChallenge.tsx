import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { ArrowLeft } from 'lucide-react';
import { CVCWord, LeaderboardEntry, VowelCategory } from '../types/phonics';
import { CIRCUS_TENTS } from '../data/cvcData';
import { audioEngine } from '../utils/audioEngine';

interface CircusChallengeProps {
  onBackToHub: () => void;
  onFinishChallenge: (entry: LeaderboardEntry) => void;
}

export const CircusChallenge: React.FC<CircusChallengeProps> = ({
  onBackToHub,
  onFinishChallenge
}) => {
  const [questions, setQuestions] = useState<CVCWord[]>([]);
  const [currentQIndex, setCurrentQIndex] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [timer, setTimer] = useState<number>(0);
  const [pupilName, setPupilName] = useState<string>('');
  const [isDone, setIsDone] = useState<boolean>(false);
  const [answeredVowel, setAnsweredVowel] = useState<VowelCategory | null>(null);

  // Pick 10 random words from all 5 tents
  useEffect(() => {
    const allWords = CIRCUS_TENTS.flatMap(t => t.words);
    const shuffled = [...allWords].sort(() => 0.5 - Math.random()).slice(0, 10);
    setQuestions(shuffled);
    setCurrentQIndex(0);
    setScore(0);
    setTimer(0);
    setIsDone(false);
  }, []);

  useEffect(() => {
    if (isDone) return;
    const interval = setInterval(() => {
      setTimer(t => t + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isDone]);

  if (questions.length === 0) return null;
  const currentWord = questions[currentQIndex];

  const handleSelectVowel = (v: VowelCategory) => {
    if (answeredVowel) return;
    setAnsweredVowel(v);
    audioEngine.playPop();

    const isCorrect = v === currentWord.vowel;
    if (isCorrect) {
      setScore(s => s + 10);
      audioEngine.playFanfare();
    }

    setTimeout(() => {
      setAnsweredVowel(null);
      if (currentQIndex < questions.length - 1) {
        setCurrentQIndex(currentQIndex + 1);
      } else {
        setIsDone(true);
        audioEngine.playBell();
        confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });
      }
    }, 800);
  };

  const handleSaveScore = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = pupilName.trim() || 'Year 1 Star';
    const entry: LeaderboardEntry = {
      id: `${Date.now()}`,
      name: finalName,
      score: score,
      totalQuestions: 10,
      timeSeconds: timer,
      date: 'Today',
      stars: score >= 90 ? 3 : score >= 60 ? 2 : 1,
      rankBadge: score === 100 ? '🥇 Circus Champion' : score >= 80 ? '🥈 High Striker Star' : '🎪 Ring Master'
    };
    onFinishChallenge(entry);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-4 bg-white/95 rounded-2xl p-3 border-2 border-amber-300 shadow-md">
        <button
          onClick={onBackToHub}
          className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-fun text-xs font-bold flex items-center gap-1 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Exit</span>
        </button>

        <div className="flex items-center gap-3">
          <span className="font-fun text-sm font-bold text-slate-800">
            Q: {Math.min(currentQIndex + 1, 10)} / 10
          </span>
          <span className="font-fun text-sm font-black text-rose-600 bg-rose-50 px-2.5 py-0.5 rounded-full border border-rose-200">
            {score} pts
          </span>
          <span className="font-mono text-xs font-bold text-slate-500">
            ⏱️ {timer}s
          </span>
        </div>
      </div>

      {!isDone ? (
        <div className="bg-white/95 rounded-3xl p-6 sm:p-8 border-4 border-amber-400 shadow-2xl text-center">
          <div className="text-5xl sm:text-6xl mb-3">
            {currentWord.correctPicture.emoji}
          </div>

          <p className="text-xs text-slate-500 mb-6 font-medium">
            Clue: {currentWord.clueText}
          </p>

          <div className="flex items-center justify-center gap-3 mb-8">
            <span className="w-16 h-20 rounded-2xl bg-amber-100 border-2 border-amber-300 font-fun text-4xl font-black text-amber-950 flex items-center justify-center shadow-inner">
              {currentWord.onset}
            </span>

            <div className="w-16 h-20 rounded-2xl border-3 border-dashed border-red-400 bg-red-50 font-fun text-4xl font-black text-red-600 flex items-center justify-center animate-pulse">
              {answeredVowel ? answeredVowel : '?'}
            </div>

            <span className="w-16 h-20 rounded-2xl bg-amber-100 border-2 border-amber-300 font-fun text-4xl font-black text-amber-950 flex items-center justify-center shadow-inner">
              {currentWord.rime}
            </span>
          </div>

          <div className="flex items-center justify-center gap-3 sm:gap-4 flex-wrap">
            {(['a', 'e', 'i', 'o', 'u'] as VowelCategory[]).map(v => (
              <button
                key={v}
                onClick={() => handleSelectVowel(v)}
                className="w-14 h-18 rounded-2xl bg-gradient-to-t from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-fun text-2xl font-black shadow-lg cursor-pointer active:scale-95 transition-transform"
              >
                {v.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="bg-white/95 rounded-3xl p-8 border-4 border-amber-400 shadow-2xl text-center">
          <div className="text-6xl mb-2">🎉</div>
          <h2 className="font-fun text-3xl font-black text-slate-900 mb-1">
            Challenge Completed!
          </h2>
          <span className="font-fun text-lg font-bold text-amber-600 block mb-4">
            Final Score: {score} / 100 in {timer} seconds
          </span>

          <form onSubmit={handleSaveScore} className="max-w-xs mx-auto">
            <label className="block text-xs font-fun font-bold text-slate-700 mb-2">
              Enter Pupil Name for Hall of Fame:
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Maya (Year 1)"
              value={pupilName}
              onChange={e => setPupilName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border-2 border-amber-300 focus:outline-hidden focus:border-red-500 font-fun text-sm mb-4 text-center"
            />
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-fun text-sm font-bold shadow-lg cursor-pointer"
            >
              Save to Classroom Leaderboard
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
