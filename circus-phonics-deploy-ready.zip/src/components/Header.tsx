import React from 'react';
import { Volume2, VolumeX, Sparkles, Trophy, Flame, Lock, Compass, Gauge, PartyPopper } from 'lucide-react';
import { CircusTent } from '../types/phonics';

interface HeaderProps {
  currentTent: CircusTent | null;
  isChallengeMode: boolean;
  isWelcomeView: boolean;
  onGoToHub: () => void;
  onGoToWelcome: () => void;
  onOpenTrophies: () => void;
  onOpenLeaderboard: () => void;
  onStartChallenge: () => void;
  onOpenTeacherStudio: () => void;
  tickets: number;
  totalStars: number;
  isMuted: boolean;
  onToggleMute: () => void;
  speechRate: number;
  onToggleSpeechRate: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTent,
  isChallengeMode,
  isWelcomeView,
  onGoToHub,
  onGoToWelcome,
  onOpenTrophies,
  onOpenLeaderboard,
  onStartChallenge,
  onOpenTeacherStudio,
  tickets,
  totalStars,
  isMuted,
  onToggleMute,
  speechRate,
  onToggleSpeechRate
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-2 border-amber-300 shadow-md px-3 sm:px-6 py-2.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onGoToWelcome}
            className="flex items-center gap-2 text-left group cursor-pointer focus:outline-hidden"
            title="Return to Grand Circus Entrance"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 to-amber-500 flex items-center justify-center text-white shadow-md text-xl group-hover:scale-105 transition-transform border-2 border-yellow-300">
              🎪
            </div>
            <div className="hidden sm:block">
              <span className="font-fun font-black text-slate-900 text-lg leading-tight block group-hover:text-red-600 transition-colors">
                Circus Phonics
              </span>
              <span className="text-[11px] font-bold text-amber-700 block tracking-wide">
                Year 1 British Blending
              </span>
            </div>
          </button>

          <div className="flex items-center gap-1.5 ml-1">
            {!isWelcomeView && (
              <button
                onClick={onGoToWelcome}
                className="px-2.5 py-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 font-fun text-xs font-bold border border-amber-300 flex items-center gap-1 cursor-pointer transition-all"
                title="Circus Welcome Gate"
              >
                <PartyPopper className="w-3.5 h-3.5 text-red-600" />
                <span className="hidden md:inline">Circus Gate</span>
              </button>
            )}

            {(currentTent || isChallengeMode) && (
              <button
                onClick={onGoToHub}
                className="px-2.5 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-fun text-xs font-bold border border-red-200 flex items-center gap-1 cursor-pointer transition-all"
                title="Back to All Tents"
              >
                <Compass className="w-3.5 h-3.5 text-red-500" />
                <span>Fairground Hub</span>
              </button>
            )}
          </div>
        </div>

        <div className="hidden lg:flex items-center gap-2">
          {currentTent ? (
            <div className="px-3 py-1 rounded-full bg-amber-100 border border-amber-300 flex items-center gap-2 shadow-xs">
              <span className="text-base">⛺</span>
              <span className="font-fun font-bold text-xs text-amber-900">
                {currentTent.name} ({currentTent.vowel.toUpperCase()})
              </span>
            </div>
          ) : isChallengeMode ? (
            <div className="px-3 py-1 rounded-full bg-red-100 border border-red-300 flex items-center gap-2 animate-pulse shadow-xs">
              <Flame className="w-4 h-4 text-red-600" />
              <span className="font-fun font-bold text-xs text-red-900">
                High Striker 10-Question Challenge
              </span>
            </div>
          ) : (
            <div className="px-3 py-1 rounded-full bg-amber-50 border border-amber-200 flex items-center gap-2 shadow-xs">
              <span className="text-sm">🎡</span>
              <span className="font-fun font-semibold text-xs text-amber-800">
                Fairground Map · 5 Vowel Tents
              </span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            onClick={onOpenLeaderboard}
            className="px-2.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-fun text-xs font-bold flex items-center gap-1 shadow-xs transition-transform cursor-pointer border border-amber-600"
            title="Classroom Hall of Fame (Top 35)"
          >
            <Trophy className="w-3.5 h-3.5 text-yellow-200" />
            <span className="hidden sm:inline">Leaderboard</span>
          </button>

          {!isChallengeMode && (
            <button
              onClick={onStartChallenge}
              className="px-2.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 active:scale-95 text-white font-fun text-xs font-bold flex items-center gap-1 shadow-xs transition-transform cursor-pointer border border-rose-700"
              title="Start 10-Question Challenge"
            >
              <Flame className="w-3.5 h-3.5 text-yellow-300" />
              <span className="hidden md:inline">Play Challenge</span>
            </button>
          )}

          <button
            onClick={onOpenTrophies}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-50 border border-amber-300 hover:bg-amber-100 transition-colors cursor-pointer"
            title="Prize Booth Trophies"
          >
            <div className="flex items-center text-amber-500 font-fun font-bold text-xs">
              <Sparkles className="w-3.5 h-3.5 mr-0.5 fill-amber-400" />
              <span>{totalStars}</span>
            </div>
            <span className="text-slate-300 text-xs">|</span>
            <div className="flex items-center text-rose-600 font-fun font-bold text-xs">
              <span className="mr-0.5">🎟️</span>
              <span>{tickets}</span>
            </div>
          </button>

          <button
            onClick={onToggleSpeechRate}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 transition-colors cursor-pointer"
            title={`Speech Rate: ${speechRate === 0.85 ? 'Slow (Learner)' : 'Normal (1.0x)'}`}
          >
            <Gauge className="w-4 h-4 text-slate-600" />
          </button>

          <button
            onClick={onToggleMute}
            className={`p-1.5 rounded-xl border transition-colors cursor-pointer ${
              isMuted
                ? 'bg-red-100 border-red-300 text-red-600'
                : 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-700'
            }`}
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={onOpenTeacherStudio}
            className="p-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 transition-colors cursor-pointer"
            title="Teacher Audio Studio (PIN: 1234)"
          >
            <Lock className="w-4 h-4 text-amber-700" />
          </button>
        </div>
      </div>
    </header>
  );
};
