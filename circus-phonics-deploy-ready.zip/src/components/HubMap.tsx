import React from 'react';
import { CircusTent, LearnerProgress } from '../types/phonics';
import { Sparkles, Flame } from 'lucide-react';

interface HubMapProps {
  tents: CircusTent[];
  progress: LearnerProgress;
  onSelectTent: (tent: CircusTent) => void;
  onOpenTrophies: () => void;
  onOpenLeaderboard: () => void;
  onStartChallenge: () => void;
  onOpenTeacherStudio: () => void;
}

export const HubMap: React.FC<HubMapProps> = ({
  tents,
  progress,
  onSelectTent,
  onStartChallenge
}) => {
  return (
    <div className="max-w-6xl mx-auto px-4 py-4 sm:py-6">
      <div className="text-center mb-6">
        <span className="font-fun text-xs sm:text-sm font-black uppercase tracking-widest text-amber-900 bg-amber-100 px-3.5 py-1 rounded-full border border-amber-300">
          🎪 Fairground Map · Year 1 Phonics 🎪
        </span>
        <h1 className="font-fun text-3xl sm:text-5xl font-black text-yellow-300 drop-shadow-md mt-2">
          Choose a Vowel Tent
        </h1>
        <p className="text-amber-100 text-xs sm:text-sm max-w-xl mx-auto font-medium mt-1">
          Pick a tent to pop helium balloons and practice pure British short vowel blending!
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-8">
        {tents.map((tent) => {
          const completedInTent = tent.words.filter(w => progress.completedWords.includes(w.id)).length;
          const totalInTent = tent.words.length;
          const isComplete = completedInTent === totalInTent;

          return (
            <div
              key={tent.id}
              onClick={() => onSelectTent(tent)}
              className="group bg-white/95 backdrop-blur-xs rounded-3xl p-5 border-3 border-amber-300 hover:border-red-400 shadow-lg hover:shadow-2xl transition-all duration-200 cursor-pointer flex flex-col justify-between hover:-translate-y-1 relative overflow-hidden"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-3xl sm:text-4xl group-hover:scale-110 transition-transform">
                    ⛺
                  </span>
                  <span className="font-mono text-xs font-black px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                    {tent.ipa}
                  </span>
                </div>

                <h3 className="font-fun text-xl sm:text-2xl font-black text-slate-900 group-hover:text-red-600 transition-colors">
                  {tent.name}
                </h3>
                <span className="font-fun text-xs font-bold text-red-600 block mb-2">
                  Short /{tent.vowel}/ · {tent.subTitle}
                </span>

                <p className="text-xs text-slate-600 line-clamp-2 font-medium mb-4">
                  {tent.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-500 fill-amber-400" />
                  <span className="font-fun text-xs font-bold text-slate-700">
                    {completedInTent} / {totalInTent} Words
                  </span>
                </div>

                <span className={`text-[11px] font-fun font-bold px-3 py-1 rounded-full ${
                  isComplete
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-red-50 text-red-700 border border-red-200 group-hover:bg-red-600 group-hover:text-white transition-colors'
                }`}>
                  {isComplete ? '🎉 Mastered!' : 'Enter Tent →'}
                </span>
              </div>
            </div>
          );
        })}

        <div
          onClick={onStartChallenge}
          className="group bg-gradient-to-br from-red-600 via-rose-600 to-amber-700 rounded-3xl p-5 border-3 border-yellow-300 shadow-xl hover:shadow-2xl transition-all duration-200 cursor-pointer flex flex-col justify-between hover:-translate-y-1 text-white relative overflow-hidden"
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-4xl animate-bounce">🔔</span>
              <span className="font-fun text-xs font-black px-2.5 py-1 rounded-full bg-yellow-400 text-amber-950">
                10-Q CHALLENGE
              </span>
            </div>

            <h3 className="font-fun text-xl sm:text-2xl font-black text-yellow-300">
              High Striker Arena
            </h3>
            <span className="font-fun text-xs font-bold text-amber-200 block mb-2">
              Pop fast & ring the golden bell!
            </span>
            <p className="text-xs text-amber-100 font-medium mb-4">
              Test all 5 vowels in a timed 10-question arcade challenge. Compete for the Classroom Hall of Fame!
            </p>
          </div>

          <div className="pt-3 border-t border-white/20 flex items-center justify-between">
            <span className="font-fun text-xs font-bold text-yellow-200 flex items-center gap-1">
              <Flame className="w-4 h-4 text-yellow-300" />
              <span>35 Pupils Hall of Fame</span>
            </span>
            <span className="font-fun text-xs font-bold px-3 py-1 rounded-full bg-yellow-400 text-amber-950 group-hover:scale-105 transition-transform">
              Start Now →
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
