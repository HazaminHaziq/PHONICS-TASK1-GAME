import React from 'react';
import { X, RotateCcw, Flame } from 'lucide-react';
import { LeaderboardEntry } from '../types/phonics';

interface LeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  leaderboard: LeaderboardEntry[];
  onResetLeaderboard: () => void;
  onStartChallenge: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  isOpen,
  onClose,
  leaderboard,
  onResetLeaderboard,
  onStartChallenge
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border-4 border-amber-400 relative max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center mx-auto mb-2 text-2xl shadow-md border-2 border-yellow-300">
            🏆
          </div>
          <span className="font-fun text-xs font-black uppercase tracking-wider text-amber-700 bg-amber-100 px-3 py-1 rounded-full border border-amber-300">
            Classroom Hall of Fame
          </span>
          <h2 className="font-fun text-2xl font-black text-slate-900 mt-1">
            Top Circus High Strikers
          </h2>
          <p className="text-xs text-slate-500">
            Displays scores and fast times for up to 35 pupils in your class.
          </p>
        </div>

        <div className="flex-1 overflow-y-auto pr-1 space-y-2 mb-4">
          {leaderboard.map((entry, index) => {
            const isTop3 = index < 3;
            const rankEmoji = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `#${index + 1}`;
            return (
              <div
                key={entry.id || index}
                className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                  isTop3
                    ? 'bg-gradient-to-r from-amber-50 to-orange-50 border-amber-300 shadow-xs'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 text-center font-fun font-black text-base text-amber-900">
                    {rankEmoji}
                  </span>
                  <div>
                    <span className="font-fun font-bold text-sm text-slate-900 block">
                      {entry.name}
                    </span>
                    <span className="text-[11px] text-slate-500 font-medium">
                      ⏱️ {entry.timeSeconds}s · {entry.stars} ⭐ Stars
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-fun font-black text-base text-red-600 block">
                    {entry.score} pts
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {entry.totalQuestions} questions
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-200">
          <button
            onClick={onResetLeaderboard}
            className="text-xs text-slate-400 hover:text-rose-600 flex items-center gap-1 font-semibold cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Scores</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onStartChallenge();
            }}
            className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-fun text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer"
          >
            <Flame className="w-4 h-4 text-yellow-300" />
            <span>Play 10-Q Challenge</span>
          </button>
        </div>
      </div>
    </div>
  );
};
