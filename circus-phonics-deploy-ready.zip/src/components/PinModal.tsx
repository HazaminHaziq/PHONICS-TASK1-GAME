import React, { useState } from 'react';
import { Lock, X, Check } from 'lucide-react';

interface PinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const PinModal: React.FC<PinModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [pin, setPin] = useState<string>('');
  const [error, setError] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleDigit = (digit: string) => {
    if (pin.length < 4) {
      const nextPin = pin + digit;
      setPin(nextPin);
      setError(false);
      if (nextPin === '1234') {
        setTimeout(() => {
          setPin('');
          onSuccess();
        }, 200);
      } else if (nextPin.length === 4) {
        setError(true);
        setTimeout(() => setPin(''), 600);
      }
    }
  };

  const handleClear = () => {
    setPin('');
    setError(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border-4 border-amber-400 text-center relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 rounded-2xl bg-amber-100 border-2 border-amber-300 text-amber-700 flex items-center justify-center mx-auto mb-3">
          <Lock className="w-6 h-6" />
        </div>

        <h3 className="font-fun text-xl font-bold text-slate-900 mb-1">
          Teacher Studio PIN
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Default Teacher PIN is <strong className="text-amber-700 font-mono">1234</strong>
        </p>

        <div className="flex justify-center gap-3 mb-6">
          {[0, 1, 2, 3].map(idx => (
            <div
              key={idx}
              className={`w-4 h-4 rounded-full border-2 transition-all ${
                pin.length > idx
                  ? error
                    ? 'bg-rose-500 border-rose-600'
                    : 'bg-amber-500 border-amber-600 scale-110'
                  : 'bg-slate-100 border-slate-300'
              }`}
            />
          ))}
        </div>

        <div className="grid grid-cols-3 gap-2.5 max-w-[220px] mx-auto">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', 'OK'].map(key => (
            <button
              key={key}
              onClick={() => {
                if (key === 'C') handleClear();
                else if (key === 'OK') {
                  if (pin === '1234') onSuccess();
                  else setError(true);
                } else handleDigit(key);
              }}
              className="h-12 rounded-xl bg-slate-50 hover:bg-amber-100 active:bg-amber-200 border border-slate-200 font-fun text-lg font-bold text-slate-800 transition-colors flex items-center justify-center cursor-pointer"
            >
              {key === 'C' ? '⌫' : key === 'OK' ? <Check className="w-5 h-5 text-emerald-600" /> : key}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
