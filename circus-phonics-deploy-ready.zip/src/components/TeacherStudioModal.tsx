import React, { useState, useEffect } from 'react';
import { X, Volume2, Upload, Trash2 } from 'lucide-react';
import { CIRCUS_TENTS } from '../data/cvcData';
import { audioEngine } from '../utils/audioEngine';
import { audioStorage } from '../utils/audioStorage';

interface TeacherStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TeacherStudioModal: React.FC<TeacherStudioModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'phonemes' | 'words'>('phonemes');
  const [customKeys, setCustomKeys] = useState<string[]>([]);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadCustomKeys();
    }
  }, [isOpen]);

  const loadCustomKeys = async () => {
    const keys = await audioStorage.getAllCustomAudioKeys();
    setCustomKeys(keys);
  };

  if (!isOpen) return null;

  const handleFileUpload = async (key: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      await audioStorage.saveCustomAudio(key, file);
      setStatusMsg(`Saved custom sound for "${key.replace(/^(phoneme_|word_)/, '')}"`);
      await loadCustomKeys();
      setTimeout(() => setStatusMsg(null), 3000);
    } catch {
      setStatusMsg('Error saving audio file.');
    }
  };

  const handleDelete = async (key: string) => {
    await audioStorage.removeCustomAudio(key);
    await loadCustomKeys();
    setStatusMsg(`Reset back to pure British default for "${key.replace(/^(phoneme_|word_)/, '')}"`);
    setTimeout(() => setStatusMsg(null), 3000);
  };

  const phonemes = ['a', 'e', 'i', 'o', 'u', 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'r', 's', 't', 'w', 'x', 'y'];
  const allWords = CIRCUS_TENTS.flatMap(t => t.words);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border-4 border-amber-400 relative max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-4 text-center">
          <span className="font-fun text-xs font-black uppercase tracking-wider text-amber-700 bg-amber-100 px-3 py-1 rounded-full border border-amber-300">
            Teacher Audio Studio
          </span>
          <h2 className="font-fun text-2xl font-black text-slate-900 mt-1">
            Custom Audio Upload & British Phonics
          </h2>
          <p className="text-xs text-slate-500">
            Preview pure British phonics sounds or upload custom recorded audio files (.mp3, .wav) for your pupils.
          </p>
        </div>

        {statusMsg && (
          <div className="mb-3 px-3 py-1.5 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold text-center">
            {statusMsg}
          </div>
        )}

        <div className="flex border-b border-slate-200 mb-4">
          <button
            onClick={() => setActiveTab('phonemes')}
            className={`flex-1 py-2 font-fun text-sm font-bold border-b-2 cursor-pointer transition-colors ${
              activeTab === 'phonemes' ? 'border-amber-500 text-amber-700' : 'border-transparent text-slate-400'
            }`}
          >
            Individual Phonemes ({phonemes.length})
          </button>
          <button
            onClick={() => setActiveTab('words')}
            className={`flex-1 py-2 font-fun text-sm font-bold border-b-2 cursor-pointer transition-colors ${
              activeTab === 'words' ? 'border-amber-500 text-amber-700' : 'border-transparent text-slate-400'
            }`}
          >
            CVC Words ({allWords.length})
          </button>
        </div>

        <div className="flex-1 overflow-y-auto pr-1 space-y-2">
          {activeTab === 'phonemes' ? (
            phonemes.map(p => {
              const storageKey = `phoneme_${p}`;
              const hasCustom = customKeys.includes(storageKey);
              return (
                <div key={p} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200 hover:border-amber-300">
                  <div className="flex items-center gap-3">
                    <span className="w-9 h-9 rounded-xl bg-amber-100 border border-amber-300 text-amber-900 font-mono font-black text-base flex items-center justify-center">
                      /{p}/
                    </span>
                    <div>
                      <span className="font-fun font-bold text-sm text-slate-800 block">
                        Letter {p.toUpperCase()}
                      </span>
                      <span className="text-[11px] font-medium text-slate-500">
                        {hasCustom ? '🎵 Custom Audio Loaded' : '🇬🇧 Pure British Phonics'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => audioEngine.playPhoneme(p)}
                      className="p-2 rounded-xl bg-white hover:bg-amber-100 text-amber-800 border border-amber-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
                      title="Test Audio"
                    >
                      <Volume2 className="w-4 h-4" />
                      <span>Play</span>
                    </button>

                    <label className="p-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold flex items-center gap-1 cursor-pointer">
                      <Upload className="w-4 h-4" />
                      <span>Upload</span>
                      <input
                        type="file"
                        accept="audio/*"
                        className="hidden"
                        onChange={(e) => handleFileUpload(storageKey, e)}
                      />
                    </label>

                    {hasCustom && (
                      <button
                        onClick={() => handleDelete(storageKey)}
                        className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 cursor-pointer"
                        title="Reset to British default"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          ) : (
            allWords.map(w => {
              const storageKey = `word_${w.word}`;
              const hasCustom = customKeys.includes(storageKey);
              return (
                <div key={w.id} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200 hover:border-amber-300">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{w.correctPicture.emoji}</span>
                    <div>
                      <span className="font-fun font-bold text-sm text-slate-800 block">
                        {w.word.toUpperCase()}
                      </span>
                      <span className="text-[11px] font-mono text-slate-500">
                        {w.fullIPA} {hasCustom && '· 🎵 Custom Audio'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => audioEngine.playWord(w.word)}
                      className="p-2 rounded-xl bg-white hover:bg-amber-100 text-amber-800 border border-amber-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="w-4 h-4" />
                      <span>Play</span>
                    </button>

                    <label className="p-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold flex items-center gap-1 cursor-pointer">
                      <Upload className="w-4 h-4" />
                      <span>Upload</span>
                      <input
                        type="file"
                        accept="audio/*"
                        className="hidden"
                        onChange={(e) => handleFileUpload(storageKey, e)}
                      />
                    </label>

                    {hasCustom && (
                      <button
                        onClick={() => handleDelete(storageKey)}
                        className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
