import React from 'react';
import { X, RotateCcw } from 'lucide-react';
import { LearnerProgress } from '../types/phonics';

interface TrophyModalProps {
  isOpen: boolean;
  onClose: () => void;
  progress: LearnerProgress;
  onResetProgress: () => void;
}

export const TrophyModal: React.FC<TrophyModalProps> = ({
  isOpen,
  onClose,
  progress,
  onResetProgress
}) => {
  if (!isOpen) return null;

  const trophies = [
    { id: 't1', title: 'First Pop', desc: 'Pop your very first vowel balloon', emoji: '🎈', req: progress.completedWords.length >= 1 },
    { id: 't2', title: 'Word Wizard', desc: 'Blend 5 different CVC words', emoji: '⭐', req: progress.completedWords.length >= 5 },
    { id: 't3', title: 'Tent Explorer', desc: 'Blend 15 words across multiple tents', emoji: '⛺', req: progress.completedWords.length >= 15 },
    { id: 't4', title: 'Carnival Champion', desc: 'Master 30 Year 1 CVC words', emoji: '🎪', req: progress.completedWords.length >= 30 },
    { id: 't5', title: 'Ticket Millionaire', desc: 'Collect 20 circus tickets', emoji: '🎟️', req: progress.tickets >= 20 },
    { id: 't6', title: 'Grand Finale Bell', desc: 'Ring the High Striker Bell with 100 points', emoji: '🔔', req: progress.tickets >= 40 },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border-4 border-amber-400 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 border-2 border-amber-300 text-2xl flex items-center justify-center mx-auto mb-2">
            🎟️
          </div>
          <h2 className="font-fun text-2xl font-black text-slate-900">
            Circus Prize Booth
          </h2>
          <p className="text-xs text-slate-500">
            You have <strong className="text-rose-600 font-bold">{progress.tickets} Circus Tickets</strong> to show for your blending achievements!
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 max-h-80 overflow-y-auto p-1 mb-4">
          {trophies.map(t => (
            <div
              key={t.id}
              className={`p-3 rounded-2xl border text-center transition-all ${
                t.req
                  ? 'bg-amber-50 border-amber-300 shadow-xs'
                  : 'bg-slate-100/60 border-slate-200 opacity-60 grayscale'
              }`}
            >
              <div className="text-3xl mb-1">{t.emoji}</div>
              <span className="font-fun text-xs font-black text-slate-900 block">
                {t.title}
              </span>
              <p className="text-[10px] text-slate-500 mt-0.5 leading-tight">
                {t.desc}
              </p>
              <span className={`inline-block mt-2 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                t.req ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-500'
              }`}>
                {t.req ? '✓ Unlocked' : 'Locked'}
              </span>
            </div>
          ))}
        </div>

        <div className="flex justify-between items-center pt-2 border-t border-slate-200">
          <button
            onClick={onResetProgress}
            className="text-[11px] text-slate-400 hover:text-rose-600 flex items-center gap-1 font-semibold cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Learner Progress</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-fun text-xs font-bold cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
