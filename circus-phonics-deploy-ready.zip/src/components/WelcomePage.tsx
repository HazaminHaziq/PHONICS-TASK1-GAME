import React from 'react';
import { CircusTent } from '../types/phonics';
import { Volume2, Trophy, Flame, ArrowRight } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';

interface WelcomePageProps {
  tents: CircusTent[];
  onEnterCircus: (tentId?: string) => void;
  onOpenLeaderboard: () => void;
  onStartChallenge: () => void;
  totalStars: number;
  tickets: number;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({
  tents,
  onEnterCircus,
  onOpenLeaderboard,
  onStartChallenge
}) => {
  const handleRingmasterGreeting = () => {
    audioEngine.playWelcomeSpeech(
      "Roll up! Roll up! Welcome to the Great Circus Balloon Pop for Year 1! Pop the balloons, blend the British sounds, and ring the bell!"
    );
  };

  const handleSelectTent = (tentId: string) => {
    audioEngine.playTilePop(520);
    onEnterCircus(tentId);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-4 sm:py-6 flex flex-col items-center">
      <div className="w-full relative rounded-3xl overflow-hidden border-4 border-amber-400 shadow-2xl bg-gradient-to-b from-amber-500 via-red-600 to-amber-900 text-white p-6 sm:p-10 mb-8 text-center">
        <div className="absolute top-0 left-0 right-0 h-4 bg-circus-stripes border-b-2 border-yellow-300 opacity-90" />

        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-yellow-400 text-amber-950 font-fun font-black text-xs sm:text-sm tracking-wider uppercase shadow-md mb-4 border border-amber-200">
          <span>🎪 PRIMARY YEAR 1 PHONICS CARNIVAL 🎪</span>
        </div>

        <h1 className="font-fun text-4xl sm:text-6xl md:text-7xl font-black text-yellow-300 drop-shadow-[0_4px_12px_rgba(0,0,0,0.6)] tracking-tight leading-tight mb-2">
          The Great Circus<br />
          <span className="text-white drop-shadow-[0_4px_10px_rgba(0,0,0,0.5)]">
            Balloon Pop!
          </span>
        </h1>

        <p className="font-body text-amber-100 text-base sm:text-lg max-w-2xl mx-auto font-medium mb-6">
          Step right up, Year 1 phonics stars! Pop floating vowel balloons, blend British sounds (a, e, i, o, u), and strike the bell for high scores!
        </p>

        <div className="flex justify-center mb-8">
          <button
            onClick={handleRingmasterGreeting}
            className="px-5 py-2.5 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md border-2 border-yellow-300 text-yellow-200 font-fun text-sm font-bold flex items-center gap-2 shadow-lg transition-all hover:scale-105 active:scale-95 cursor-pointer"
          >
            <Volume2 className="w-5 h-5 text-yellow-300 animate-pulse" />
            <span>Hear Ringmaster Welcome (British Voice)</span>
          </button>
        </div>

        <div className="flex flex-col items-center gap-3">
          <button
            onClick={() => onEnterCircus()}
            className="group px-8 sm:px-14 py-5 sm:py-6 rounded-3xl bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-500 hover:from-yellow-200 hover:to-amber-400 active:scale-95 text-amber-950 font-fun text-2xl sm:text-4xl font-black shadow-[0_12px_28px_rgba(245,158,11,0.5)] border-4 border-white flex items-center gap-3 cursor-pointer transition-all hover:scale-105"
            aria-label="Enter the Circus and Start Playing"
          >
            <span className="text-3xl sm:text-5xl group-hover:rotate-12 transition-transform select-none">
              🎪
            </span>
            <span className="tracking-wide drop-shadow-xs">
              STEP RIGHT UP! ENTER CIRCUS
            </span>
            <span className="text-3xl sm:text-5xl group-hover:-rotate-12 transition-transform select-none">
              🎈
            </span>
          </button>
          <span className="text-xs sm:text-sm font-bold text-yellow-200 uppercase tracking-widest">
            ✨ Tap above to explore all 5 Vowel Tents! ✨
          </span>
        </div>
      </div>

      <div className="w-full mb-8">
        <div className="text-center mb-4">
          <span className="font-fun text-xs sm:text-sm font-bold uppercase tracking-widest text-amber-900 bg-amber-100/90 px-3.5 py-1 rounded-full border border-amber-300">
            How To Play in 3 Fun Steps
          </span>
          <h2 className="font-fun text-2xl sm:text-3xl font-black text-slate-900 mt-1">
            Easy as 1, 2, 3!
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/95 rounded-3xl p-5 border-3 border-amber-300 shadow-lg flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-2xl bg-rose-100 border-2 border-rose-300 flex items-center justify-center text-3xl mb-3 shadow-inner">
              👂
            </div>
            <span className="font-fun text-xs font-black uppercase tracking-wider text-rose-600 bg-rose-50 px-2.5 py-0.5 rounded-full border border-rose-200 mb-1">
              Step 1: Look & Listen
            </span>
            <h3 className="font-fun text-lg font-black text-slate-900 mb-1">
              Consonant Frame
            </h3>
            <p className="text-xs text-slate-600 font-medium leading-relaxed">
              Look at the missing middle vowel slot: <strong className="text-rose-600 font-mono text-sm">b [ ? ] g</strong>. Listen to the picture clue!
            </p>
          </div>

          <div className="bg-white/95 rounded-3xl p-5 border-3 border-amber-300 shadow-lg flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-2xl bg-amber-100 border-2 border-amber-300 flex items-center justify-center text-3xl mb-3 shadow-inner">
              🎈
            </div>
            <span className="font-fun text-xs font-black uppercase tracking-wider text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200 mb-1">
              Step 2: Pop Balloon
            </span>
            <h3 className="font-fun text-lg font-black text-slate-900 mb-1">
              Tap Floating Vowel
            </h3>
            <p className="text-xs text-slate-600 font-medium leading-relaxed">
              Watch 5 colorful balloons drift up (a, e, i, o, u). Tap the correct vowel to pop it into the slot!
            </p>
          </div>

          <div className="bg-white/95 rounded-3xl p-5 border-3 border-amber-300 shadow-lg flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-2xl bg-emerald-100 border-2 border-emerald-300 flex items-center justify-center text-3xl mb-3 shadow-inner">
              🎟️
            </div>
            <span className="font-fun text-xs font-black uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 mb-1">
              Step 3: Blend & Win
            </span>
            <h3 className="font-fun text-lg font-black text-slate-900 mb-1">
              Blend British Sounds
            </h3>
            <p className="text-xs text-slate-600 font-medium leading-relaxed">
              Hear <strong className="text-emerald-700">/b/ - /æ/ - /ɡ/ = bag!</strong> Celebrate with fanfare and earn circus tickets!
            </p>
          </div>
        </div>
      </div>

      <div className="w-full bg-white/90 rounded-3xl p-6 border-2 border-amber-300 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-fun text-lg sm:text-xl font-black text-slate-900">
              🎪 Choose a Vowel Tent Directly
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              Year 1 Short Vowel Sounds (8 CVC Words per Tent)
            </p>
          </div>
          <button
            onClick={() => onEnterCircus()}
            className="text-xs font-fun font-bold text-red-600 hover:text-red-700 flex items-center gap-1 cursor-pointer"
          >
            <span>See Fairground Map</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {tents.map(tent => (
            <button
              key={tent.id}
              onClick={() => handleSelectTent(tent.id)}
              className="p-3.5 rounded-2xl bg-gradient-to-b from-amber-50 to-orange-50/80 hover:from-amber-100 hover:to-orange-100 border-2 border-amber-300 hover:border-red-400 shadow-xs hover:shadow-md transition-all flex flex-col items-center cursor-pointer group text-center active:scale-95"
            >
              <span className="text-3xl sm:text-4xl group-hover:scale-110 transition-transform mb-1 select-none">
                ⛺
              </span>
              <span className="font-fun text-base sm:text-lg font-black text-red-700">
                Tent {tent.vowel.toUpperCase()}
              </span>
              <span className="text-[11px] font-mono font-bold text-amber-900 bg-amber-200/80 px-2 py-0.5 rounded-md mt-0.5">
                {tent.ipa}
              </span>
              <span className="text-[10px] text-slate-500 font-bold mt-1">
                {tent.words.length} Words
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="w-full mt-4 flex flex-col sm:flex-row items-center justify-between gap-3 bg-amber-100/90 rounded-2xl p-4 border border-amber-300">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center text-xl shrink-0 shadow-xs">
            🏆
          </div>
          <div className="text-left">
            <span className="font-fun text-sm font-black text-amber-950 block">
              Classroom Hall of Fame Active
            </span>
            <span className="text-xs text-amber-800 font-medium">
              Tracks up to 35 pupils in your class! Ready for friendly phonics challenges.
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenLeaderboard}
            className="px-3.5 py-2 rounded-xl bg-white hover:bg-amber-50 text-amber-900 border border-amber-300 font-fun text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-600" />
            <span>Leaderboard</span>
          </button>
          <button
            onClick={onStartChallenge}
            className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-fun text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
          >
            <Flame className="w-3.5 h-3.5 text-yellow-300" />
            <span>10-Q Challenge</span>
          </button>
        </div>
      </div>
    </div>
  );
};
