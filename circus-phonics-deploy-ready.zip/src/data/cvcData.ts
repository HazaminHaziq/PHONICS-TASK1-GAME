import { CircusTent, LeaderboardEntry } from '../types/phonics';

export const CIRCUS_TENTS: CircusTent[] = [
  {
    id: 'a',
    name: "Acrobat Arena",
    vowel: 'a',
    ipa: "/æ/",
    subTitle: "Short /æ/ as in Cat",
    themeTitle: "High-Flying Aerial Feats",
    imagePath: "tent_a_acrobat",
    tentColor: 'bg-rose-500',
    stripeColor: 'border-rose-400',
    accentBg: 'bg-rose-50',
    accentBorder: 'border-rose-200',
    description: "Leap and swing with playful /æ/ words! Open mouth wide, tongue low at the front.",
    mouthGuide: "Open mouth wide like eating an apple. Say /æ/!",
    words: [
      {
        id: "cat", word: "cat", onset: "c", vowel: 'a', rime: "t",
        onsetIPA: "/k/", vowelIPA: "/æ/", rimeIPA: "/t/", fullIPA: "/kæt/",
        audioPronunciationText: "c... a... t... cat",
        onsetAudioHint: "c", vowelAudioHint: 'a', rimeAudioHint: "t",
        clueText: "A furry circus pet that loves to chase mice and purr!",
        meaning: "A small domesticated feline carnivore.",
        sentence: "The circus cat leaped through a hoop of ribbons.",
        correctPicture: { id: "pic-cat", word: "cat", emoji: "🐱", label: "Cat" },
        distractors: [
          { id: 'pic-dog', word: "dog", emoji: "🐶", label: "Dog" },
          { id: 'pic-bat', word: "bat", emoji: "🦇", label: "Bat" }
        ]
      },
      {
        id: "hat", word: "hat", onset: "h", vowel: 'a', rime: "t",
        onsetIPA: "/h/", vowelIPA: "/æ/", rimeIPA: "/t/", fullIPA: "/hæt/",
        audioPronunciationText: "h... a... t... hat",
        onsetAudioHint: "h", vowelAudioHint: 'a', rimeAudioHint: "t",
        clueText: "The magician wears this tall shiny top hat on stage!",
        meaning: "A shaped covering for the head.",
        sentence: "A fluffy rabbit popped out of the circus hat!",
        correctPicture: { id: "pic-hat", word: "hat", emoji: "🎩", label: "Hat" },
        distractors: [
          { id: 'pic-cap', word: "cap", emoji: "🧢", label: "Cap" },
          { id: 'pic-mat', word: "mat", emoji: "🧘", label: "Mat" }
        ]
      },
      {
        id: "bag", word: "bag", onset: "b", vowel: 'a', rime: "g",
        onsetIPA: "/b/", vowelIPA: "/æ/", rimeIPA: "/ɡ/", fullIPA: "/bæɡ/",
        audioPronunciationText: "b... a... g... bag",
        onsetAudioHint: "b", vowelAudioHint: 'a', rimeAudioHint: "g",
        clueText: "A colorful sack used to carry juggling balls and tickets!",
        meaning: "A container made of flexible material.",
        sentence: "The clown pulled sixty balloons out of a tiny red bag.",
        correctPicture: { id: "pic-bag", word: "bag", emoji: "🎒", label: "Bag" },
        distractors: [
          { id: 'pic-box', word: "box", emoji: "📦", label: "Box" },
          { id: 'pic-tag', word: "tag", emoji: "🏷️", label: "Tag" }
        ]
      },
      {
        id: "bat", word: "bat", onset: "b", vowel: 'a', rime: "t",
        onsetIPA: "/b/", vowelIPA: "/æ/", rimeIPA: "/t/", fullIPA: "/bæt/",
        audioPronunciationText: "b... a... t... bat",
        onsetAudioHint: "b", vowelAudioHint: 'a', rimeAudioHint: "t",
        clueText: "A flying creature of the night that swoops beneath the tent roof!",
        meaning: "A flying nocturnal mammal.",
        sentence: "A little bat flew across the starry fairground sky.",
        correctPicture: { id: "pic-bat", word: "bat", emoji: "🦇", label: "Bat" },
        distractors: [
          { id: 'pic-bird', word: "bird", emoji: "🐦", label: "Bird" },
          { id: 'pic-owl', word: "owl", emoji: "🦉", label: "Owl" }
        ]
      },
      {
        id: "jam", word: "jam", onset: "j", vowel: 'a', rime: "m",
        onsetIPA: "/dʒ/", vowelIPA: "/æ/", rimeIPA: "/m/", fullIPA: "/dʒæm/",
        audioPronunciationText: "j... a... m... jam",
        onsetAudioHint: "j", vowelAudioHint: 'a', rimeAudioHint: "m",
        clueText: "Sweet strawberry spread smeared over carnival toast!",
        meaning: "A sweet spread made from boiled fruit and sugar.",
        sentence: "The acrobat ate sweet berry jam before her routine.",
        correctPicture: { id: "pic-jam", word: "jam", emoji: "🍓", label: "Jam" },
        distractors: [
          { id: 'pic-pie', word: "pie", emoji: "🥧", label: "Pie" },
          { id: 'pic-honey', word: "honey", emoji: "🍯", label: "Honey" }
        ]
      },
      {
        id: "fan", word: "fan", onset: "f", vowel: 'a', rime: "n",
        onsetIPA: "/f/", vowelIPA: "/æ/", rimeIPA: "/n/", fullIPA: "/fæn/",
        audioPronunciationText: "f... a... n... fan",
        onsetAudioHint: "f", vowelAudioHint: 'a', rimeAudioHint: "n",
        clueText: "A spinning tool that blows cool breeze inside the warm big tent!",
        meaning: "An apparatus with rotating blades that creates a current of air.",
        sentence: "The carnival audience cooled off with a paper fan.",
        correctPicture: { id: "pic-fan", word: "fan", emoji: "🪭", label: "Fan" },
        distractors: [
          { id: 'pic-wind', word: "wind", emoji: "💨", label: "Wind" },
          { id: 'pic-pan', word: "pan", emoji: "🍳", label: "Pan" }
        ]
      },
      {
        id: "pan", word: "pan", onset: "p", vowel: 'a', rime: "n",
        onsetIPA: "/p/", vowelIPA: "/æ/", rimeIPA: "/n/", fullIPA: "/pæn/",
        audioPronunciationText: "p... a... n... pan",
        onsetAudioHint: "p", vowelAudioHint: 'a', rimeAudioHint: "n",
        clueText: "A metal cooking dish used to pop warm circus corn!",
        meaning: "A metal container used for cooking food.",
        sentence: "The chef sizzled popcorn in a shiny circus pan.",
        correctPicture: { id: "pic-pan", word: "pan", emoji: "🍳", label: "Pan" },
        distractors: [
          { id: 'pic-pot', word: "pot", emoji: "🍲", label: "Pot" },
          { id: 'pic-cup', word: "cup", emoji: "🥤", label: "Cup" }
        ]
      },
      {
        id: "map", word: "map", onset: "m", vowel: 'a', rime: "p",
        onsetIPA: "/m/", vowelIPA: "/æ/", rimeIPA: "/p/", fullIPA: "/mæp/",
        audioPronunciationText: "m... a... p... map",
        onsetAudioHint: "m", vowelAudioHint: 'a', rimeAudioHint: "p",
        clueText: "A colorful guide that shows where every game and tent is located!",
        meaning: "A visual representation of an area.",
        sentence: "The children followed the fairground map to the big top.",
        correctPicture: { id: "pic-map", word: "map", emoji: "🗺️", label: "Map" },
        distractors: [
          { id: 'pic-book', word: "book", emoji: "📖", label: "Book" },
          { id: 'pic-compass', word: "compass", emoji: "🧭", label: "Compass" }
        ]
      },
    ]
  },
  {
    id: 'e',
    name: "Elephant Pavilion",
    vowel: 'e',
    ipa: "/e/",
    subTitle: "Short /e/ as in Pen",
    themeTitle: "Gentle Giant Feats & Balanced Balls",
    imagePath: "tent_e_elephant",
    tentColor: 'bg-emerald-500',
    stripeColor: 'border-emerald-400',
    accentBg: 'bg-emerald-50',
    accentBorder: 'border-emerald-200',
    description: "Listen to the gentle trumpet of /e/! Tongue mid-height, relaxed smile.",
    mouthGuide: "Relax your lips in a gentle smile. Say /e/ as in elephant!",
    words: [
      {
        id: "pen", word: "pen", onset: "p", vowel: 'e', rime: "n",
        onsetIPA: "/p/", vowelIPA: "/e/", rimeIPA: "/n/", fullIPA: "/pen/",
        audioPronunciationText: "p... e... n... pen",
        onsetAudioHint: "p", vowelAudioHint: 'e', rimeAudioHint: "n",
        clueText: "Used to write down scores and sign circus certificates!",
        meaning: "An instrument for writing with ink.",
        sentence: "The judge wrote a ten with his gold circus pen.",
        correctPicture: { id: "pic-pen", word: "pen", emoji: "🖊️", label: "Pen" },
        distractors: [
          { id: 'pic-pencil', word: "pencil", emoji: "✏️", label: "Pencil" },
          { id: 'pic-pin', word: "pin", emoji: "📌", label: "Pin" }
        ]
      },
      {
        id: "net", word: "net", onset: "n", vowel: 'e', rime: "t",
        onsetIPA: "/n/", vowelIPA: "/e/", rimeIPA: "/t/", fullIPA: "/net/",
        audioPronunciationText: "n... e... t... net",
        onsetAudioHint: "n", vowelAudioHint: 'e', rimeAudioHint: "t",
        clueText: "The safety mesh underneath high trapeze acrobats!",
        meaning: "A meshed fabric stretched out for safety.",
        sentence: "The trapeze star landed softly into the safety net.",
        correctPicture: { id: "pic-net", word: "net", emoji: "🥅", label: "Net" },
        distractors: [
          { id: 'pic-rope', word: "rope", emoji: "🪢", label: "Rope" },
          { id: 'pic-tent', word: "tent", emoji: "⛺", label: "Tent" }
        ]
      },
      {
        id: "hen", word: "hen", onset: "h", vowel: 'e', rime: "n",
        onsetIPA: "/h/", vowelIPA: "/e/", rimeIPA: "/n/", fullIPA: "/hen/",
        audioPronunciationText: "h... e... n... hen",
        onsetAudioHint: "h", vowelAudioHint: 'e', rimeAudioHint: "n",
        clueText: "A feathered farm bird that clucks and pecks grain in the petting ring!",
        meaning: "A female bird, especially a domestic fowl.",
        sentence: "A speckled hen pecked popcorn near the circus tent.",
        correctPicture: { id: "pic-hen", word: "hen", emoji: "🐔", label: "Hen" },
        distractors: [
          { id: 'pic-duck', word: "duck", emoji: "🦆", label: "Duck" },
          { id: 'pic-egg', word: "egg", emoji: "🥚", label: "Egg" }
        ]
      },
      {
        id: "bed", word: "bed", onset: "b", vowel: 'e', rime: "d",
        onsetIPA: "/b/", vowelIPA: "/e/", rimeIPA: "/d/", fullIPA: "/bed/",
        audioPronunciationText: "b... e... d... bed",
        onsetAudioHint: "b", vowelAudioHint: 'e', rimeAudioHint: "d",
        clueText: "Where tired circus performers sleep after the grand evening finale!",
        meaning: "A piece of furniture for sleep.",
        sentence: "The acrobat climbed into a cozy caravan bed.",
        correctPicture: { id: "pic-bed", word: "bed", emoji: "🛏️", label: "Bed" },
        distractors: [
          { id: 'pic-chair', word: "chair", emoji: "🪑", label: "Chair" },
          { id: 'pic-box', word: "box", emoji: "📦", label: "Box" }
        ]
      },
      {
        id: "red", word: "red", onset: "r", vowel: 'e', rime: "d",
        onsetIPA: "/r/", vowelIPA: "/e/", rimeIPA: "/d/", fullIPA: "/red/",
        audioPronunciationText: "r... e... d... red",
        onsetAudioHint: "r", vowelAudioHint: 'e', rimeAudioHint: "d",
        clueText: "The brightest color on the clown’s round nose and tent roof!",
        meaning: "The color of strawberries, rubies, or blood.",
        sentence: "The big circus balloon was bright cherry red.",
        correctPicture: { id: "pic-red", word: "red", emoji: "🔴", label: "Red" },
        distractors: [
          { id: 'pic-blue', word: "blue", emoji: "🔵", label: "Blue" },
          { id: 'pic-yellow', word: "yellow", emoji: "🟡", label: "Yellow" }
        ]
      },
      {
        id: "leg", word: "leg", onset: "l", vowel: 'e', rime: "g",
        onsetIPA: "/l/", vowelIPA: "/e/", rimeIPA: "/ɡ/", fullIPA: "/leɡ/",
        audioPronunciationText: "l... e... g... leg",
        onsetAudioHint: "l", vowelAudioHint: 'e', rimeAudioHint: "g",
        clueText: "What the stilt walker extends high into the air to walk tall!",
        meaning: "Each of the limbs on which a person or animal walks.",
        sentence: "The stilt walker stepped forward on a giant wooden leg.",
        correctPicture: { id: "pic-leg", word: "leg", emoji: "🦵", label: "Leg" },
        distractors: [
          { id: 'pic-foot', word: "foot", emoji: "🦶", label: "Foot" },
          { id: 'pic-arm', word: "arm", emoji: "💪", label: "Arm" }
        ]
      },
      {
        id: "wet", word: "wet", onset: "w", vowel: 'e', rime: "t",
        onsetIPA: "/w/", vowelIPA: "/e/", rimeIPA: "/t/", fullIPA: "/wet/",
        audioPronunciationText: "w... e... t... wet",
        onsetAudioHint: "w", vowelAudioHint: 'e', rimeAudioHint: "t",
        clueText: "Covered in water after the clown splashes a funny comedy bucket!",
        meaning: "Covered or saturated with water.",
        sentence: "The clown got soaking wet from a surprise flower sprayer!",
        correctPicture: { id: "pic-wet", word: "wet", emoji: "💦", label: "Wet" },
        distractors: [
          { id: 'pic-dry', word: "dry", emoji: "☀️", label: "Dry" },
          { id: 'pic-fire', word: "fire", emoji: "🔥", label: "Fire" }
        ]
      },
      {
        id: "pet", word: "pet", onset: "p", vowel: 'e', rime: "t",
        onsetIPA: "/p/", vowelIPA: "/e/", rimeIPA: "/t/", fullIPA: "/pet/",
        audioPronunciationText: "p... e... t... pet",
        onsetAudioHint: "p", vowelAudioHint: 'e', rimeAudioHint: "t",
        clueText: "A friendly animal you can stroke gently in the junior circus barn!",
        meaning: "A tame animal kept for companionship.",
        sentence: "The children reached out to pet the friendly miniature pony.",
        correctPicture: { id: "pic-pet", word: "pet", emoji: "🐕", label: "Pet" },
        distractors: [
          { id: 'pic-toy', word: "toy", emoji: "🧸", label: "Toy" },
          { id: 'pic-bone', word: "bone", emoji: "🦴", label: "Bone" }
        ]
      },
    ]
  },
  {
    id: 'i',
    name: "Illusionist Dome",
    vowel: 'i',
    ipa: "/ɪ/",
    subTitle: "Short /ɪ/ as in Pin",
    themeTitle: "Magic Hats & Mystery Wands",
    imagePath: "tent_i_ringmaster",
    tentColor: 'bg-indigo-500',
    stripeColor: 'border-indigo-400',
    accentBg: 'bg-indigo-50',
    accentBorder: 'border-indigo-200',
    description: "Discover enchanting /ɪ/ words! Quick, short sound with tongue raised forward.",
    mouthGuide: "Small narrow opening, short voice sound. Say /ɪ/ as in ink!",
    words: [
      {
        id: "pin", word: "pin", onset: "p", vowel: 'i', rime: "n",
        onsetIPA: "/p/", vowelIPA: "/ɪ/", rimeIPA: "/n/", fullIPA: "/pɪn/",
        audioPronunciationText: "p... i... n... pin",
        onsetAudioHint: "p", vowelAudioHint: 'i', rimeAudioHint: "n",
        clueText: "A sharp shiny needle used to secure ribbons and circus badges!",
        meaning: "A small thin piece of metal with a sharp point.",
        sentence: "The ringmaster pinned a shiny gold star onto his lapel.",
        correctPicture: { id: "pic-pin", word: "pin", emoji: "📌", label: "Pin" },
        distractors: [
          { id: 'pic-needle', word: "needle", emoji: "🪡", label: "Needle" },
          { id: 'pic-nail', word: "nail", emoji: "🔨", label: "Nail" }
        ]
      },
      {
        id: "bin", word: "bin", onset: "b", vowel: 'i', rime: "n",
        onsetIPA: "/b/", vowelIPA: "/ɪ/", rimeIPA: "/n/", fullIPA: "/bɪn/",
        audioPronunciationText: "b... i... n... bin",
        onsetAudioHint: "b", vowelAudioHint: 'i', rimeAudioHint: "n",
        clueText: "Where we throw empty popcorn boxes to keep the circus grounds clean!",
        meaning: "A container to hold rubbish.",
        sentence: "Always toss your candy wrappers into the recycling bin.",
        correctPicture: { id: "pic-bin", word: "bin", emoji: "🗑️", label: "Bin" },
        distractors: [
          { id: 'pic-box', word: "box", emoji: "📦", label: "Box" },
          { id: 'pic-basket', word: "basket", emoji: "🧺", label: "Basket" }
        ]
      },
      {
        id: "sit", word: "sit", onset: "s", vowel: 'i', rime: "t",
        onsetIPA: "/s/", vowelIPA: "/ɪ/", rimeIPA: "/t/", fullIPA: "/sɪt/",
        audioPronunciationText: "s... i... t... sit",
        onsetAudioHint: "s", vowelAudioHint: 'i', rimeAudioHint: "t",
        clueText: "What the audience does on the wooden bleachers when the music starts!",
        meaning: "Adopt or be in a position in which one’s weight is supported by one’s buttocks.",
        sentence: "Please sit down as the grand circus show begins!",
        correctPicture: { id: "pic-sit", word: "sit", emoji: "🪑", label: "Sit" },
        distractors: [
          { id: 'pic-stand', word: "stand", emoji: "🧍", label: "Stand" },
          { id: 'pic-run', word: "run", emoji: "🏃", label: "Run" }
        ]
      },
      {
        id: "wig", word: "wig", onset: "w", vowel: 'i', rime: "g",
        onsetIPA: "/w/", vowelIPA: "/ɪ/", rimeIPA: "/ɡ/", fullIPA: "/wɪɡ/",
        audioPronunciationText: "w... i... g... wig",
        onsetAudioHint: "w", vowelAudioHint: 'i', rimeAudioHint: "g",
        clueText: "Curly rainbow artificial hair worn by the laughing clown!",
        meaning: "A covering of artificial or natural hair for the head.",
        sentence: "The clown wore a bright orange curly wig that bobbed when he danced.",
        correctPicture: { id: "pic-wig", word: "wig", emoji: "🤡", label: "Wig" },
        distractors: [
          { id: 'pic-mask', word: "mask", emoji: "🎭", label: "Mask" },
          { id: 'pic-hat', word: "hat", emoji: "🎩", label: "Hat" }
        ]
      },
      {
        id: "lip", word: "lip", onset: "l", vowel: 'i', rime: "p",
        onsetIPA: "/l/", vowelIPA: "/ɪ/", rimeIPA: "/p/", fullIPA: "/lɪp/",
        audioPronunciationText: "l... i... p... lip",
        onsetAudioHint: "l", vowelAudioHint: 'i', rimeAudioHint: "p",
        clueText: "Part of the mouth painted with bright red makeup!",
        meaning: "Either of the two fleshy margins of the mouth.",
        sentence: "The mime pressed a painted finger to his lip for silence.",
        correctPicture: { id: "pic-lip", word: "lip", emoji: "👄", label: "Lip" },
        distractors: [
          { id: 'pic-teeth', word: "teeth", emoji: "🦷", label: "Teeth" },
          { id: 'pic-eye', word: "eye", emoji: "👁️", label: "Eye" }
        ]
      },
      {
        id: "tin", word: "tin", onset: "t", vowel: 'i', rime: "n",
        onsetIPA: "/t/", vowelIPA: "/ɪ/", rimeIPA: "/n/", fullIPA: "/tɪn/",
        audioPronunciationText: "t... i... n... tin",
        onsetAudioHint: "t", vowelAudioHint: 'i', rimeAudioHint: "n",
        clueText: "A shiny metal can filled with roasted fairground nuts!",
        meaning: "A container made of tinplate.",
        sentence: "The vendor opened a sealed tin of circus biscuits.",
        correctPicture: { id: "pic-tin", word: "tin", emoji: "🥫", label: "Tin" },
        distractors: [
          { id: 'pic-cup', word: "cup", emoji: "🥤", label: "Cup" },
          { id: 'pic-jar', word: "jar", emoji: "🫙", label: "Jar" }
        ]
      },
      {
        id: "pig", word: "pig", onset: "p", vowel: 'i', rime: "g",
        onsetIPA: "/p/", vowelIPA: "/ɪ/", rimeIPA: "/ɡ/", fullIPA: "/pɪɡ/",
        audioPronunciationText: "p... i... g... pig",
        onsetAudioHint: "p", vowelAudioHint: 'i', rimeAudioHint: "g",
        clueText: "A pink animal with a curly tail running in the comedy race!",
        meaning: "A domesticated omnivorous mammal with a snout and short legs.",
        sentence: "The clever little pig nudged a rubber ball with its snout.",
        correctPicture: { id: "pic-pig", word: "pig", emoji: "🐷", label: "Pig" },
        distractors: [
          { id: 'pic-sheep', word: "sheep", emoji: "🐑", label: "Sheep" },
          { id: 'pic-cow', word: "cow", emoji: "🐮", label: "Cow" }
        ]
      },
      {
        id: "hit", word: "hit", onset: "h", vowel: 'i', rime: "t",
        onsetIPA: "/h/", vowelIPA: "/ɪ/", rimeIPA: "/t/", fullIPA: "/hɪt/",
        audioPronunciationText: "h... i... t... hit",
        onsetAudioHint: "h", vowelAudioHint: 'i', rimeAudioHint: "t",
        clueText: "Swing the rubber mallet with all your might on the High Striker!",
        meaning: "Bring one’s hand or a tool into contact with someone or something quickly.",
        sentence: "Hit the striker bell hard to ring the golden bell!",
        correctPicture: { id: "pic-hit", word: "hit", emoji: "🔨", label: "Hit" },
        distractors: [
          { id: 'pic-drop', word: "drop", emoji: "⬇️", label: "Drop" },
          { id: 'pic-kick', word: "kick", emoji: "⚽", label: "Kick" }
        ]
      },
    ]
  },
  {
    id: 'o',
    name: "Cannonball Coliseum",
    vowel: 'o',
    ipa: "/ɒ/",
    subTitle: "Short /ɒ/ as in Pot",
    themeTitle: "Booming Cannons & Human Fireworks",
    imagePath: "tent_o_cannonball",
    tentColor: 'bg-amber-500',
    stripeColor: 'border-amber-400',
    accentBg: 'bg-amber-50',
    accentBorder: 'border-amber-200',
    description: "Feel the explosive blast of /ɒ/! Round lips wide, sound from the back.",
    mouthGuide: "Make a wide round \"O\" shape with your lips. Say /ɒ/ as in cannonball!",
    words: [
      {
        id: "pot", word: "pot", onset: "p", vowel: 'o', rime: "t",
        onsetIPA: "/p/", vowelIPA: "/ɒ/", rimeIPA: "/t/", fullIPA: "/pɒt/",
        audioPronunciationText: "p... o... t... pot",
        onsetAudioHint: "p", vowelAudioHint: 'o', rimeAudioHint: "t",
        clueText: "A round cooking vessel used to stir warm caramel apples!",
        meaning: "A rounded container typically of metal or earthenware.",
        sentence: "Bubbling sweet syrup steamed inside the big circus pot.",
        correctPicture: { id: "pic-pot", word: "pot", emoji: "🍲", label: "Pot" },
        distractors: [
          { id: 'pic-pan', word: "pan", emoji: "🍳", label: "Pan" },
          { id: 'pic-plate', word: "plate", emoji: "🍽️", label: "Plate" }
        ]
      },
      {
        id: "dog", word: "dog", onset: "d", vowel: 'o', rime: "g",
        onsetIPA: "/d/", vowelIPA: "/ɒ/", rimeIPA: "/ɡ/", fullIPA: "/dɒɡ/",
        audioPronunciationText: "d... o... g... dog",
        onsetAudioHint: "d", vowelAudioHint: 'o', rimeAudioHint: "g",
        clueText: "A trained pup that jumps through glittery hoops on two legs!",
        meaning: "A domesticated carnivorous mammal that barks.",
        sentence: "The spotted dog performed a joyful backflip.",
        correctPicture: { id: "pic-dog", word: "dog", emoji: "🐶", label: "Dog" },
        distractors: [
          { id: 'pic-cat', word: "cat", emoji: "🐱", label: "Cat" },
          { id: 'pic-fox', word: "fox", emoji: "🦊", label: "Fox" }
        ]
      },
      {
        id: "box", word: "box", onset: "b", vowel: 'o', rime: "x",
        onsetIPA: "/b/", vowelIPA: "/ɒ/", rimeIPA: "/ks/", fullIPA: "/bɒks/",
        audioPronunciationText: "b... o... x... box",
        onsetAudioHint: "b", vowelAudioHint: 'o', rimeAudioHint: "x",
        clueText: "A decorated square crate where the magician steps inside!",
        meaning: "A container with flat sides.",
        sentence: "The magician closed the velvet box and made it disappear.",
        correctPicture: { id: "pic-box", word: "box", emoji: "📦", label: "Box" },
        distractors: [
          { id: 'pic-bag', word: "bag", emoji: "🎒", label: "Bag" },
          { id: 'pic-trunk', word: "trunk", emoji: "🧳", label: "Trunk" }
        ]
      },
      {
        id: "top", word: "top", onset: "t", vowel: 'o', rime: "p",
        onsetIPA: "/t/", vowelIPA: "/ɒ/", rimeIPA: "/p/", fullIPA: "/tɒp/",
        audioPronunciationText: "t... o... p... top",
        onsetAudioHint: "t", vowelAudioHint: 'o', rimeAudioHint: "p",
        clueText: "The very peak of the high circus big tent where the flag waves!",
        meaning: "The highest point or part.",
        sentence: "A bright gold pennant fluttered at the top of the tent.",
        correctPicture: { id: "pic-top", word: "top", emoji: "🎪", label: "Top" },
        distractors: [
          { id: 'pic-bottom', word: "bottom", emoji: "⬇️", label: "Bottom" },
          { id: 'pic-middle', word: "middle", emoji: "↔️", label: "Middle" }
        ]
      },
      {
        id: "hop", word: "hop", onset: "h", vowel: 'o', rime: "p",
        onsetIPA: "/h/", vowelIPA: "/ɒ/", rimeIPA: "/p/", fullIPA: "/hɒp/",
        audioPronunciationText: "h... o... p... hop",
        onsetAudioHint: "h", vowelAudioHint: 'o', rimeAudioHint: "p",
        clueText: "A springy jump on one foot over carnival ribbons!",
        meaning: "To jump on one foot or leap playfully.",
        sentence: "The acrobat did a bouncy hop across the balance beam.",
        correctPicture: { id: "pic-hop", word: "hop", emoji: "🦘", label: "Hop" },
        distractors: [
          { id: 'pic-crawl', word: "crawl", emoji: "🐛", label: "Crawl" },
          { id: 'pic-sleep', word: "sleep", emoji: "😴", label: "Sleep" }
        ]
      },
      {
        id: "mop", word: "mop", onset: "m", vowel: 'o', rime: "p",
        onsetIPA: "/m/", vowelIPA: "/ɒ/", rimeIPA: "/p/", fullIPA: "/mɒp/",
        audioPronunciationText: "m... o... p... mop",
        onsetAudioHint: "m", vowelAudioHint: 'o', rimeAudioHint: "p",
        clueText: "A cleaning bundle of yarn used to wipe water spills off the stage!",
        meaning: "An implement consisting of a bundle of thick loose strings.",
        sentence: "The caretaker mopped the circus ring floor until it shone.",
        correctPicture: { id: "pic-mop", word: "mop", emoji: "🧹", label: "Mop" },
        distractors: [
          { id: 'pic-brush', word: "brush", emoji: "🖌️", label: "Brush" },
          { id: 'pic-sponge', word: "sponge", emoji: "🧽", label: "Sponge" }
        ]
      },
      {
        id: "hot", word: "hot", onset: "h", vowel: 'o', rime: "t",
        onsetIPA: "/h/", vowelIPA: "/ɒ/", rimeIPA: "/t/", fullIPA: "/hɒt/",
        audioPronunciationText: "h... o... t... hot",
        onsetAudioHint: "h", vowelAudioHint: 'o', rimeAudioHint: "t",
        clueText: "Steamy and sizzling, like roasted peanuts fresh from the vendor cart!",
        meaning: "Having a high degree of heat or temperature.",
        sentence: "The fresh roasted nuts were delicious and hot to touch.",
        correctPicture: { id: "pic-hot", word: "hot", emoji: "🔥", label: "Hot" },
        distractors: [
          { id: 'pic-cold', word: "cold", emoji: "🧊", label: "Cold" },
          { id: 'pic-wet', word: "wet", emoji: "💦", label: "Wet" }
        ]
      },
      {
        id: "log", word: "log", onset: "l", vowel: 'o', rime: "g",
        onsetIPA: "/l/", vowelIPA: "/ɒ/", rimeIPA: "/ɡ/", fullIPA: "/lɒɡ/",
        audioPronunciationText: "l... o... g... log",
        onsetAudioHint: "l", vowelAudioHint: 'o', rimeAudioHint: "g",
        clueText: "A round tree trunk rolled by performers on the sawdust floor!",
        meaning: "A part of the trunk or a large branch of a felled tree.",
        sentence: "The performers balanced atop a spinning wooden log.",
        correctPicture: { id: "pic-log", word: "log", emoji: "🪵", label: "Log" },
        distractors: [
          { id: 'pic-rock', word: "rock", emoji: "🪨", label: "Rock" },
          { id: 'pic-leaf', word: "leaf", emoji: "🍂", label: "Leaf" }
        ]
      },
    ]
  },
  {
    id: 'u',
    name: "Unicycle Undertow",
    vowel: 'u',
    ipa: "/ʌ/",
    subTitle: "Short /ʌ/ as in Sun",
    themeTitle: "Spinning Wheels & High-Wire Stunts",
    imagePath: "tent_u_unicycle",
    tentColor: 'bg-purple-500',
    stripeColor: 'border-purple-400',
    accentBg: 'bg-purple-50',
    accentBorder: 'border-purple-200',
    description: "Master the high-wire bounce of /ʌ/! Relaxed jaw, quick puff of voice.",
    mouthGuide: "Drop jaw halfway, open throat cleanly. Say /ʌ/ as in umbrella!",
    words: [
      {
        id: "sun", word: "sun", onset: "s", vowel: 'u', rime: "n",
        onsetIPA: "/s/", vowelIPA: "/ʌ/", rimeIPA: "/n/", fullIPA: "/sʌn/",
        audioPronunciationText: "s... u... n... sun",
        onsetAudioHint: "s", vowelAudioHint: 'u', rimeAudioHint: "n",
        clueText: "The warm golden light shining over the carnival fairground!",
        meaning: "The star around which the earth orbits.",
        sentence: "The afternoon sun warmed the colorful circus tents.",
        correctPicture: { id: "pic-sun", word: "sun", emoji: "☀️", label: "Sun" },
        distractors: [
          { id: 'pic-moon', word: "moon", emoji: "🌙", label: "Moon" },
          { id: 'pic-star', word: "star", emoji: "⭐", label: "Star" }
        ]
      },
      {
        id: "cup", word: "cup", onset: "c", vowel: 'u', rime: "p",
        onsetIPA: "/k/", vowelIPA: "/ʌ/", rimeIPA: "/p/", fullIPA: "/kʌp/",
        audioPronunciationText: "c... u... p... cup",
        onsetAudioHint: "c", vowelAudioHint: 'u', rimeAudioHint: "p",
        clueText: "A striped paper vessel filled with carnival lemonade!",
        meaning: "A small bowl-shaped container for drinking.",
        sentence: "She drank cold iced juice from a tall circus cup.",
        correctPicture: { id: "pic-cup", word: "cup", emoji: "🥤", label: "Cup" },
        distractors: [
          { id: 'pic-plate', word: "plate", emoji: "🍽️", label: "Plate" },
          { id: 'pic-bowl', word: "bowl", emoji: "🥣", label: "Bowl" }
        ]
      },
      {
        id: "bus", word: "bus", onset: "b", vowel: 'u', rime: "s",
        onsetIPA: "/b/", vowelIPA: "/ʌ/", rimeIPA: "/s/", fullIPA: "/bʌs/",
        audioPronunciationText: "b... u... s... bus",
        onsetAudioHint: "b", vowelAudioHint: 'u', rimeAudioHint: "s",
        clueText: "The big painted coach that transports the circus troupe between towns!",
        meaning: "A large motor vehicle carrying passengers.",
        sentence: "The brass band arrived in a bright red double-decker bus.",
        correctPicture: { id: "pic-bus", word: "bus", emoji: "🚌", label: "Bus" },
        distractors: [
          { id: 'pic-car', word: "car", emoji: "🚗", label: "Car" },
          { id: 'pic-train', word: "train", emoji: "🚂", label: "Train" }
        ]
      },
      {
        id: "bug", word: "bug", onset: "b", vowel: 'u', rime: "g",
        onsetIPA: "/b/", vowelIPA: "/ʌ/", rimeIPA: "/ɡ/", fullIPA: "/bʌɡ/",
        audioPronunciationText: "b... u... g... bug",
        onsetAudioHint: "b", vowelAudioHint: 'u', rimeAudioHint: "g",
        clueText: "A little ladybird that crawls along the wooden carnival fence!",
        meaning: "A small insect or creeping creature.",
        sentence: "A tiny polka-dot bug rested on the red circus tent.",
        correctPicture: { id: "pic-bug", word: "bug", emoji: "🐞", label: "Bug" },
        distractors: [
          { id: 'pic-spider', word: "spider", emoji: "🕷️", label: "Spider" },
          { id: 'pic-bee', word: "bee", emoji: "🐝", label: "Bee" }
        ]
      },
      {
        id: "rug", word: "rug", onset: "r", vowel: 'u', rime: "g",
        onsetIPA: "/r/", vowelIPA: "/ʌ/", rimeIPA: "/ɡ/", fullIPA: "/rʌɡ/",
        audioPronunciationText: "r... u... g... rug",
        onsetAudioHint: "r", vowelAudioHint: 'u', rimeAudioHint: "g",
        clueText: "A thick patterned velvet carpet spread across the center ring!",
        meaning: "A floor covering of thick woven material.",
        sentence: "The contortionist practiced on a soft velvet rug.",
        correctPicture: { id: "pic-rug", word: "rug", emoji: "🧶", label: "Rug" },
        distractors: [
          { id: 'pic-bed', word: "bed", emoji: "🛏️", label: "Bed" },
          { id: 'pic-towel', word: "towel", emoji: "🧖", label: "Towel" }
        ]
      },
      {
        id: "nut", word: "nut", onset: "n", vowel: 'u', rime: "t",
        onsetIPA: "/n/", vowelIPA: "/ʌ/", rimeIPA: "/t/", fullIPA: "/nʌt/",
        audioPronunciationText: "n... u... t... nut",
        onsetAudioHint: "n", vowelAudioHint: 'u', rimeAudioHint: "t",
        clueText: "A crunchy snack with a hard shell enjoyed at the grand parade!",
        meaning: "A fruit consisting of a hard shell around an edible kernel.",
        sentence: "The squirrel cracked an acorn nut behind the carnival stall.",
        correctPicture: { id: "pic-nut", word: "nut", emoji: "🥜", label: "Nut" },
        distractors: [
          { id: 'pic-seed', word: "seed", emoji: "🌰", label: "Seed" },
          { id: 'pic-apple', word: "apple", emoji: "🍎", label: "Apple" }
        ]
      },
      {
        id: "mud", word: "mud", onset: "m", vowel: 'u', rime: "d",
        onsetIPA: "/m/", vowelIPA: "/ʌ/", rimeIPA: "/d/", fullIPA: "/mʌd/",
        audioPronunciationText: "m... u... d... mud",
        onsetAudioHint: "m", vowelAudioHint: 'u', rimeAudioHint: "d",
        clueText: "Wet squishy dirt outside the tent after a sudden carnival rain!",
        meaning: "Soft, sticky matter resulting from the mixing of earth and water.",
        sentence: "The clown wore shiny yellow galoshes to splash through the mud.",
        correctPicture: { id: "pic-mud", word: "mud", emoji: "🟤", label: "Mud" },
        distractors: [
          { id: 'pic-sand', word: "sand", emoji: "🏖️", label: "Sand" },
          { id: 'pic-water', word: "water", emoji: "💧", label: "Water" }
        ]
      },
      {
        id: "tub", word: "tub", onset: "t", vowel: 'u', rime: "b",
        onsetIPA: "/t/", vowelIPA: "/ʌ/", rimeIPA: "/b/", fullIPA: "/tʌb/",
        audioPronunciationText: "t... u... b... tub",
        onsetAudioHint: "t", vowelAudioHint: 'u', rimeAudioHint: "b",
        clueText: "A big round wooden basin where the acrobats wash their juggling hoops!",
        meaning: "A wide, open, deep, typically round container.",
        sentence: "The sea lion splashed water joyfully from a large wooden tub.",
        correctPicture: { id: "pic-tub", word: "tub", emoji: "🛁", label: "Tub" },
        distractors: [
          { id: 'pic-sink', word: "sink", emoji: "🚰", label: "Sink" },
          { id: 'pic-bucket', word: "bucket", emoji: "🪣", label: "Bucket" }
        ]
      },
    ]
  },
];

export const INITIAL_LEADERBOARD: LeaderboardEntry[] = [
  { id: '1', name: 'Adam (Year 1 Alpha)', score: 100, totalQuestions: 10, timeSeconds: 24, date: 'Today', stars: 3, rankBadge: '🥇 Circus Champion' },
  { id: '2', name: 'Nurul (Year 1 Beta)', score: 90, totalQuestions: 10, timeSeconds: 29, date: 'Today', stars: 3, rankBadge: '🥈 High Striker Star' },
  { id: '3', name: 'Liam (Year 1 Gamma)', score: 90, totalQuestions: 10, timeSeconds: 34, date: 'Yesterday', stars: 2, rankBadge: '🥉 Trapeze Ace' },
  { id: '4', name: 'Siti (Year 1 Alpha)', score: 80, totalQuestions: 10, timeSeconds: 38, date: 'Yesterday', stars: 2, rankBadge: '🎪 Ring Master' },
  { id: '5', name: 'Arun (Year 1 Beta)', score: 80, totalQuestions: 10, timeSeconds: 42, date: '2 days ago', stars: 2, rankBadge: '🎈 Balloon Blaster' }
];
