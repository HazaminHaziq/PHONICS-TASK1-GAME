import { audioStorage } from './audioStorage';

interface FormantProfile {
  f1: number;
  f2: number;
  f3: number;
  duration: number;
  noiseType?: 'aspirate' | 'fricative' | 'burst' | 'voiced' | 'nasal';
  burstFreq?: number;
}

const PHONEME_PROFILES: Record<string, FormantProfile> = {
  // British short vowels
  'a': { f1: 800, f2: 1750, f3: 2600, duration: 0.28, noiseType: 'voiced' },
  'e': { f1: 550, f2: 1900, f3: 2650, duration: 0.24, noiseType: 'voiced' },
  'i': { f1: 400, f2: 2150, f3: 2750, duration: 0.22, noiseType: 'voiced' },
  'o': { f1: 600, f2: 950, f3: 2500, duration: 0.28, noiseType: 'voiced' },
  'u': { f1: 640, f2: 1200, f3: 2550, duration: 0.24, noiseType: 'voiced' },

  // Consonants
  'b': { f1: 200, f2: 700, f3: 2400, duration: 0.18, noiseType: 'burst', burstFreq: 300 },
  'c': { f1: 300, f2: 1500, f3: 2600, duration: 0.22, noiseType: 'aspirate', burstFreq: 1800 },
  'd': { f1: 250, f2: 1800, f3: 2800, duration: 0.18, noiseType: 'burst', burstFreq: 2200 },
  'f': { f1: 350, f2: 1400, f3: 2500, duration: 0.32, noiseType: 'fricative', burstFreq: 3500 },
  'g': { f1: 240, f2: 1950, f3: 2700, duration: 0.18, noiseType: 'burst', burstFreq: 1600 },
  'h': { f1: 500, f2: 1500, f3: 2500, duration: 0.28, noiseType: 'aspirate', burstFreq: 1200 },
  'j': { f1: 300, f2: 2100, f3: 2800, duration: 0.26, noiseType: 'fricative', burstFreq: 2400 },
  'k': { f1: 300, f2: 1500, f3: 2600, duration: 0.22, noiseType: 'aspirate', burstFreq: 1800 },
  'l': { f1: 380, f2: 1200, f3: 2700, duration: 0.28, noiseType: 'voiced' },
  'm': { f1: 250, f2: 1000, f3: 2200, duration: 0.32, noiseType: 'nasal' },
  'n': { f1: 260, f2: 1700, f3: 2600, duration: 0.30, noiseType: 'nasal' },
  'p': { f1: 200, f2: 700, f3: 2200, duration: 0.20, noiseType: 'aspirate', burstFreq: 500 },
  'r': { f1: 350, f2: 1100, f3: 1600, duration: 0.30, noiseType: 'voiced' },
  's': { f1: 300, f2: 1800, f3: 3500, duration: 0.35, noiseType: 'fricative', burstFreq: 4500 },
  't': { f1: 220, f2: 1800, f3: 2800, duration: 0.18, noiseType: 'aspirate', burstFreq: 3200 },
  'v': { f1: 250, f2: 1300, f3: 2400, duration: 0.28, noiseType: 'voiced' },
  'w': { f1: 300, f2: 700, f3: 2200, duration: 0.26, noiseType: 'voiced' },
  'x': { f1: 300, f2: 1700, f3: 3300, duration: 0.35, noiseType: 'fricative', burstFreq: 4000 },
  'y': { f1: 280, f2: 2200, f3: 2900, duration: 0.28, noiseType: 'voiced' },
  'z': { f1: 250, f2: 1700, f3: 3200, duration: 0.32, noiseType: 'fricative', burstFreq: 4000 }
};

class AudioEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private speechRate: number = 0.85;

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  setRate(rate: number) {
    this.speechRate = rate;
  }

  // Play custom uploaded audio or synthesize
  async playPhoneme(phoneme: string): Promise<void> {
    if (this.isMuted) return;
    // Normalise the IPA "ɡ" to the plain letter "g" so it always finds a sound profile
    const clean = phoneme.toLowerCase().trim().replace(/ɡ/g, 'g');

    const customBlob = await audioStorage.getCustomAudio(`phoneme_${clean}`);
    if (customBlob) {
      await this.playAudioBlob(customBlob);
      return;
    }

    this.playAcousticPhoneme(clean);
  }

  private playAudioBlob(blob: Blob): Promise<void> {
    return new Promise((resolve) => {
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.onended = () => {
        URL.revokeObjectURL(url);
        resolve();
      };
      audio.onerror = () => {
        URL.revokeObjectURL(url);
        resolve();
      };
      audio.play().catch(() => resolve());
    });
  }

  // Synthesize acoustic formant phoneme
  playAcousticPhoneme(phoneme: string) {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const profile = PHONEME_PROFILES[phoneme] || {
      f1: 500, f2: 1500, f3: 2500, duration: 0.25, noiseType: 'voiced'
    };

    const now = this.ctx.currentTime;
    const dur = profile.duration;

    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(190, now);
    osc.frequency.exponentialRampToValueAtTime(170, now + dur);

    const f1 = this.ctx.createBiquadFilter();
    f1.type = 'bandpass';
    f1.frequency.setValueAtTime(profile.f1, now);
    f1.Q.setValueAtTime(7, now);

    const f2 = this.ctx.createBiquadFilter();
    f2.type = 'bandpass';
    f2.frequency.setValueAtTime(profile.f2, now);
    f2.Q.setValueAtTime(8, now);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.25, now + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);

    osc.connect(f1);
    osc.connect(f2);
    f1.connect(gain);
    f2.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + dur);
  }

  // Play full CVC word with British accent
  async playWord(word: string): Promise<void> {
    if (this.isMuted) return;
    const clean = word.toLowerCase().trim();

    const customBlob = await audioStorage.getCustomAudio(`word_${clean}`);
    if (customBlob) {
      await this.playAudioBlob(customBlob);
      return;
    }

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(clean);
      utter.rate = this.speechRate;
      utter.pitch = 1.1;

      const voices = window.speechSynthesis.getVoices();
      const british = voices.find(v => v.lang.includes('en-GB') || v.name.includes('British') || v.name.includes('UK'));
      if (british) {
        utter.voice = british;
      } else {
        utter.lang = 'en-GB';
      }
      window.speechSynthesis.speak(utter);
    }
  }

  // Ringmaster welcome announcement
  playWelcomeSpeech(text: string) {
    if (this.isMuted || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.rate = 0.9;
    utter.pitch = 1.05;
    const voices = window.speechSynthesis.getVoices();
    const british = voices.find(v => v.lang.includes('en-GB') || v.name.includes('UK'));
    if (british) utter.voice = british;
    else utter.lang = 'en-GB';
    window.speechSynthesis.speak(utter);
  }

  playPop() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(450, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.12);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.12);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.12);
  }

  playFanfare() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, i) => {
      setTimeout(() => {
        if (!this.ctx) return;
        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.3);
      }, i * 75);
    });
  }

  playBell() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1400, now);
    osc.frequency.exponentialRampToValueAtTime(1380, now + 0.6);
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.6);
  }

  playTilePop(freq = 440) {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);
    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.1);
  }
}

export const audioEngine = new AudioEngine();
